﻿using Razorpay.Api;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RazorPOC
{
    class Program
    {
        static void Main(string[] args)
        {
            string baseUrl = "";
            string key = "rzp_test_9wyYS8fhHp8PTm";
            string secret = "tqh0VeGKlv7dI3VqLlMjsr9l";
            RazorpayClient client = new RazorpayClient(key, secret);

            Dictionary<string, object> options = new Dictionary<string, object>();
            options.Add("amount", 10);
            Payment payment = new Payment();
            var paymentId = payment.Capture(options);
        }
    }
}
